from pyrogram import *
import asyncio
import requests
API_ID = 22160733
API_HASH = 'c95e81b40eba3404ac130f4a9f235e4c'
phone = open('/root/plus/prift.txt', 'r').read().replace('\n', '')
client = f'/root/plus/session/{phone}'
DEX = Client(client, api_id=API_ID, api_hash=API_HASH)

@DEX.on_message(filters.regex(r"Dx") & filters.user("me"))
async def dex1(client, message):
    try:
        try:
            information = "".join(message.text.split(maxsplit=1)[1:]).split(" ", 2)
            sleeptime = information[0]
            messagess = information[1]
            text = information[2]
            pace = message.chat.id
            await message.delete()
            with open(f'{phone}.txt', 'w') as fo:
                fo.write('on')
        except:
            await message.edit(
                'طريقة تفعيل النشر خاطأ\nيرجئ تطبيق الأوامر والشرح بشكل صحيح\nلعرض الأوامر فقط اكتب (الأوامر)')
        for _ in range(int(messagess)):
            with open(f'{phone}.txt', 'r') as file:
                if 'on' in file.read():
                    await client.send_message(pace, str(text))
                    await asyncio.sleep(int(sleeptime))
                elif 'off' in file.read():
                    break
    except Exception as er:
        print(er)


@DEX.on_message(filters.regex(r"Duser") & filters.user("me"))
async def dex_user(client, message):
    try:
        information = "".join(message.text.split(maxsplit=1)[1:]).split(" ", 2)
        print(information)
        user = information[0].replace('@','')
        p = requests.get(f"https://fragment.com/username/{user}").text
        if "On auction" in p or 'Available' in p:
            await message.edit(' مرفوع مزاد✅ ')
        elif 'Sold' in p:
            await message.edit(' مرفوع ومباع ايضا في المزاد✅ ')
        elif 'Taken' in p:
            await message.edit(' ما مرفوع مزاد❎ ')
    except Exception as er:
        print(er)


@DEX.on_message(filters.regex(r"id") & filters.user("me"))
async def get_id(client, message):
    try:
        me = await DEX.get_me()
        id = me.id
        await message.edit(str(id))
    except Exception as er:
        print(er)


@DEX.on_message(filters.regex(r"Dstop") & filters.user("me"))
async def stop_publish(client, message):
    try:
        with open(f'{phone}.txt', 'w') as fi:
            fi.write('off')
        await message.edit('تم توقيف النشر انتظر بقدر الوقت المضاف للنشر لعدم حدوث أخطاء في التوقيف')
    except Exception as er:
        print(er)


@DEX.on_message(filters.regex(r"Ds") & filters.user("me"))
async def show_status(client, message):
    try:
        await message.edit('''•————————•
    Welcame 
    السورس شغال بدون أخطاء
    Channel : @iiiNil
    •————————•''')
    except Exception as er:
        print(er)


@DEX.on_message(filters.regex(r"Dall") & filters.user("me"))
async def send_message_to_all(client, message):
    command_length = len(".Dall")
    message_text = message.text[command_length:]

    async for dialog in DEX.get_dialogs():
        if dialog.chat.type == enums.ChatType.PRIVATE:
            try:
                await DEX.send_message(dialog.chat.id, text=message_text)
            except Exception as e:
                print(f"Failed to send message to {dialog.chat.id}: {str(e)}")


@DEX.on_message(filters.regex(r"الاوامر") & filters.user("me"))
async def show_commands(client, message):
    await message.edit('''للنشر :
اكتب Dx بعدها الوقت بين رسالة ورسالة بعدها عدد الرسائل
بعدها تكتب رسالتك (الكليشة)، مثال 
Dx 300 100 (كليشتك)

لتوقيف النشر  :
اكتب Dstop لتوقيف النشر ويجب الانتظار وقت بقد الوقت المضاف للنشر قبل البدأ بالنشر الجديد 
يعني: يجب الانتظار 300 ثانية لأننا كتبنا في المثال 300 ثانية لكي نبدأ بالنشر الجديد 

للفحص اكتب DS 

اذاعة خاص :
للاذاعة في الخاص اكتب Dall + رسالتك (كليشتك) مثال
Dall اهلاً وسهلاً

لاضهار ايديك اكتب id 

لفحص يوزر ما اذا كان مرفوع مزاد او لا او مرفوع ومباع اكتب DexUser + يوزرك ، مثال
Duser @LuLuu
اذا واجهت مشاكل راسلني 
Owner : @LuLuu , Channel : @iiiNil''')


print(f'started! {DEX.name}')
DEX.run()
